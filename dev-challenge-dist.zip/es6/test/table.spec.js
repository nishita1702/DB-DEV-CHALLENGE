var table = require('./es6/table');

describe("table", () => {

    test("sample", () => {
      expect(2 + 2).toBe(4);
    });
  })
  